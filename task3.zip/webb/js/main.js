

function box(){

    document.querySelector(".box").style.display="block"

}
setInterval(box,5000)